package com.example.mybookkeeping;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class HomepageActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        findViewById(R.id.btn_exit).setOnClickListener(this);
        findViewById(R.id.btn_accounting).setOnClickListener(this);
        findViewById(R.id.btn_budget).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = null;
        int id = view.getId();
        if (id == R.id.btn_accounting) {
            intent = new Intent(this, ManageActivity.class);
            startActivity(intent);
        } else if (id == R.id.btn_budget) {
            intent = new Intent(this, SearchRecordActivity.class);
            startActivity(intent);
        }else if (id==R.id.btn_exit){
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("退出操作")
                    .setMessage("确定退出，不继续玩玩？")
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);
                        }
                    }).setNegativeButton("继续留下！", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    }).create();
            dialog.show();
        }
    }
}