package com.example.mybookkeeping;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.example.mybookkeeping.Bean.User;
import com.example.mybookkeeping.Database.UserTB;
import com.example.mybookkeeping.Utils.ToastUtil;

import java.util.List;

public class ForgetPassword extends AppCompatActivity {
    private EditText et_reg_account;
    private EditText et_reg_pwd;
    private UserTB mHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        et_reg_account = findViewById(R.id.et_account);
        et_reg_pwd = findViewById(R.id.et_password);

    }

    /*public void onClick(View view) {
        int id = view.getId();//按钮
        if (id == R.id.btn_ChangePwd) {
            String account = et_reg_account.getText().toString();
            String pwd = et_reg_pwd.getText().toString();
            User user = new User();
            if (TextUtils.isEmpty(account)) {
                ToastUtil.show(this, "账号不能为空");
            }

            List<User> userList = mHelper.selectByAccount(account);
            if (!userList.isEmpty()) {  //说明已经被注册过了
                ToastUtil.show(this, "该账号已存在");
                user.setAccount(account);
                user.setPassword(pwd);

            }
            /*if (TextUtils.isEmpty(pwd)) {
                ToastUtil.show(this, "密码不能为空");
                return;
            }
            /*user.setAccount(account);
            user.setPassword(pwd);
            long rowId = mHelper.insert(user);
            if (rowId != -1) {
                ToastUtil.show(this, "修改成功");
                Intent intent = new Intent(ForgetPassword.this, LoginActivity.class);
                startActivity(intent);
            } else {
                ToastUtil.show(this, "修改失败");

            }
        }
    }*/
}